// var string1 = "Мама", string2 = "мыла", string3 = "раму" ;
// var count = 10;
// var string4 = "раз";
// console.log(string1 + " " + string2 + " " + string3 + " " + count + " " + string4);
// var number = 325;
// var string = "";
// if (number <= 0 || number >= 1000) {
// 	console.log(`${number} вне требумоего диапазона `);
// }
// else{
// 	if (number % 2 == 0) {
// 		string = "Четное"ж
// 	}
// 	else{
// 		string = "Нечетное"
// 	}
// 	if (number >= 10 && ) {}
// }
// var K = 5;
// var N = 15;
// for (var i = 1; i <= N; i++) {
// 	console.log(K);
	
// }
// var A = 5;
// var B = 15;
// var count  = 0;
// for (var i  = B - 1; i > (A + 1); i--) {
// 	console.log(i);
// 	count++;
// 	console.log(count);
// }
var price = 200;
for (i = 1; i <= 10; i++)  {
	console.log(i*price)	
}