// Вывести числа от 4 до 400.
// for (var i = 4; i <= 400 ; i++) {
// 	console.log(i)
// }

//Выести числа в последовательности 47 10 13 с помощью цыкла.
// for (var i =7; i = 13; i = i +3) {
// 	console.log(i);
	
// }

// Вывести все года от 1983 до 2017
// for (var i = 1983; i = 2017; i++) {
// 	console.log(i);

// }

//Вывести числа -4 -2 0 2 4 6 ... 100
// for (var i = -4 ; i = 100; i + 2) {
// 	console.log(i);

// }

// Таблица умножения на 7
// for ( var i = 7; i = 63; i = i +7 ) {
//  console.log(i);
//  break;
// }


var i = 7;
do {
  i = i + 7;
  break;
} while (i = 63);
console.log( i );


