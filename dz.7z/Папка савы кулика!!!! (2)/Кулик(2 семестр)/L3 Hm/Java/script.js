var A = 3
var B = 5
var X = 0
for (i = A; i<=b ;i++) {
	X = X + 1;
}
console.log(); 
