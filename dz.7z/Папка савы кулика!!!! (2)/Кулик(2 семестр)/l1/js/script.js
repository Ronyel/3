var number1 = 5
var number2 = 6
var number3 = -5;
var NumberofNumbers = 0;
if (number1 > 0) {
	NumberofNumbers++
}
if (number2 > 0) {
	NumberofNumbers++;
}
if (number3 > 0) {
	NumberofNumbers++
}
console.log(NumberofNumbers);